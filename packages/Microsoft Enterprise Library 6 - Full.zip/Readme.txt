﻿MICROSOFT ENTERPRISE LIBRARY 6

Summary: This package contains all the Enterprise Library binaries and scripts.

Note: For the Semantic Logging Application Block Out-of-Process service, a separate package is available for download.

The most up-to-date version of the release notes and known issues is available online:
http://aka.ms/el6release


Microsoft patterns & practices
http://microsoft.com/practices
